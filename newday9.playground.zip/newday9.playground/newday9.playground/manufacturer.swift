//
//  manufacturer.swift
//  newday9.playground
//
//  Created by MacStudent on 2018-02-08.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import Foundation
class Manufacturer{
    var name: String?


init(name: String) {
    self.name = name
}

    convenience init() {
        self.init(name: "[Unknown]")
}
    func display(){
        print("name : ",self.name!)
    }
    deinit{
        print("Manufacturer is deinitialized")
    }
    
}

