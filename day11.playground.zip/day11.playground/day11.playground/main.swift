//
//  main.swift
//  day11.playground
//
//  Created by MacStudent on 2018-02-12.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import Foundation

print("Hello, World!")

var objStud = Student()
//objStud.display()
//objStud.display(message: "JK")

var p1 = parttime()
//p1.setStudentName(name : "JK")

var obj = Extendparttime()
obj.setStudentName(sname: "nav")
class T : Extendparttime
{
    override init() {
        super.init()
        print("Display T")
    }
}
