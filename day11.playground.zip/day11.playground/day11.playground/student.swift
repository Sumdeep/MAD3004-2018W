//
//  student.swift
//  day11.playground
//
//  Created by MacStudent on 2018-02-12.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import Cocoa



class Student
{
     var sname: String?
    init()
    {
        self.sname = "Student Name"
    }
    func setStudentName(sname: String)
    {
        self.sname = sname
    }
    func getStudentName() -> String
    {
        return self.sname!
        
    }
    private func display()
    {
     print("I am private method of Student Class")
        
    }
    private func display(message: String)
    {
        print("Hello, \(message)")
    }
}
private class fulltime: Student
{
    var subject : String?
    override init()
    {
        self.subject = "Fulltime"
        
    }
    private func setSubjectName (subject: String)
    {
        self.subject = subject
    }
private func display()
{
    print("Fulltime class")
    super.display ( message : "File Private")
    }
}

