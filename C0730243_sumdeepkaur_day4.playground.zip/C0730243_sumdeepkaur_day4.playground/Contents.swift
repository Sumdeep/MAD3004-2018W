//: Playground - noun: a place where people can play

import UIKit

var str = "Hello, playground"
//sorted closure
var months = [4,3,1,6,5,2]
print(months.sorted())

func reverse(_ s1: Int, _ s2: Int) -> Bool {
    return s1 > s2
    
}
var reversedMonths = months.sorted(by:reverse)
print("reversedMonths",reversedMonths)

func increasing(_
    s1:Int, _ s2:Int) -> Bool {
return s1 < s2
}

var increasingMonths = months.sorted(by: increasing)
print("increasing months : ",increasingMonths)

var reverseClosure = months.sorted(by:{
    (s1: Int, s2: Int) -> Bool in
return s1 > s2

})
print("reverseClosure",reverseClosure)

var inferTypes =  months.sorted(by:{
//(s1, s2) in return s1 < s2
(s1, s2) in s1 < s2
})

print("inferTypes : ",inferTypes)

print("shorthand argument : ", months.sorted(by: {$0 < $1}))

print("operator methods : ",months.sorted(by: <))

var three = [1,3,4,5,6,8,9,12,15]
print("three : ", three)

var modThree = three.filter({ $0 % 3 == 0})
print(",modThree : ", modThree)

func makeIncrementer(forIncrementer amount: Int) -> () -> Int {
    var runningTotal = 0
    
    func incrementer() -> Int {
        runningTotal += amount
        return runningTotal
}
return incrementer
}

let incrementByTen = makeIncrementer(forIncrementer: 10)

print("first call : ",incrementByTen())
print("second call : ",incrementByTen())
print("third call : ",incrementByTen())

let incrementBySeven = makeIncrementer(forIncrementer: 7)
print("Increment by seven 1 : ",incrementBySeven())
print("Increment by seven 2 : ",incrementBySeven())

print("fourth call : ",incrementByTen())

let incrementBySevenAgain = incrementBySeven
print("Increment by seven 3 : ",incrementBySevenAgain())

var errorList = [404,414,402,431,455,440]
print("Total Errors : ",errorList.count)

let debugger = { errorList.remove(at: 0)}
print("Total Errors :",errorList.count)

print("Now solving \(debugger())!")
print("Total Errors : ",errorList.count)

print("Error List :",errorList)

func solve(error debugger: @autoclosure () -> Int) {
    print("Now solving \(debugger())!")
}

solve(error: errorList.remove(at:0))
print("Error List : ", errorList)

struct project{
    var title = ""
    var hours = 0
    func display(){
        print("Project Title : ",title)
        print("Total work hours required : ",hours)
    }
}

var LMSProject = project(title: "Moodle",hours :200)
print(LMSProject)

LMSProject.display()

LMSProject.hours = 300
LMSProject.display()

class Manager{
    var name : String = ""
    var productOwner : Bool = true
var currentProjects = project()
}


let mgrCanada = Manager()
mgrCanada.name = "JK"
mgrCanada.productOwner = true
mgrCanada.currentProjects=project(title: "Sales Reporting",hours:20)

print("mgrCanada Name : ",mgrCanada.name)
print("mgrCanada product Owner : ",mgrCanada.productOwner)
print("mgrCanada current Project Title : ",mgrCanada.currentProjects.title)


struct address{
    var street = "265 Yorkland Blvd"
    var city = "North York"
    var postalCode = "M1H1Y1"
}


var lambton = address()
print("Lambton :",lambton)

var cestar = lambton
print("Cestar:",cestar)

cestar.street = "271 yorkland blvd"
cestar.postalCode = "M1H3Y3"
print("Cestar :",cestar)
print("Lambton : ",lambton)


class Institute{
    var street = "265 Yorkland Blvd"
    var city = "North York"
    var postalCode = "M1H1Y1"
}



var myLambton = Institute()
print("myLambton street: ",myLambton.street)
print("myLambton city: ",myLambton.city)
print("myLambton postalCode: ",myLambton.postalCode)
    

myLambton.street = "271 Yorkland Blvd"



