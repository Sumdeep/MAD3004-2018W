//: Playground - noun: a place where people can play

import UIKit

var str = "Hello, playground"
print(str)
print("This is our String:\(str)",terminator: " ")
//use separator for separating multiple prompts

print("1","2","3","4","5",separator: "..")

var n1=10
print("Numberb 1 :",n1,"String :",str)
var n2=20
print("Number 2 :",n2)
var sum = n1 + n2
print("Sum is : ",sum)
print("Sum = ",n1+n2)

/*
n1 = "test"
*/
print("n1 : ",n1)
var a:Int = 10

print("a = ",a)

var greet:String = "Good Morning"
print("Greetings :",greet)
var emoji = "☺️";
print(" its a \(emoji) hour")
let pi = 3.14

print("Pi = ",pi)
var Pi = 10
let myNum:Int? //optional
//myNum = 10
myNum = nil
if myNum != nil{
    print("myNum : ",myNum!)
}
else{
    print("myNum is Nil")
}
//optional values
let possibleNumber = "hello" //"hello"
let convertedNumber:Int?
convertedNumber = Int(possibleNumber)
if convertedNumber != nil{
    print("ConvertedNumber" , convertedNumber!)
}
else{
    print("ConvertedNumber is nil")
}
for i in 1..<5{
    print ("i = ",i)
}
let languages:[String]
languages = ["English","Spanish","French"]
for i in languages{
    print("language : " , i)
}
var answer: Int = 1
for _ in 1...5{
    answer *= 5;
}
    var Interval:Int = 5
    for i in stride(from: 0, to: 50, by: Interval){
        print(i," ",terminator: " ")
    }

var j = 1

while (j < 5) {
    print( "Value of j is \(j)")
    j = j + 1
 
j = 5
}
    repeat{
        print("Repeat : ",j)
        j = j + 2
    }while (j<=10)
switch num1 {
 case 100 :
print("Value of num1 is 100")
 case 10,15 :
 print("Value of num1 is either 10 or 15")
 case 5 :
 print("Value of num1 is 5")
 default :
 print("default case")
 }

    








 
