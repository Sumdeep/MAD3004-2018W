//: Playground - noun: a place where people can play

import UIKit
var namesOfIntegers = [Int: String]()

print("namesOfIntegers: ",namesOfIntegers)

    
namesOfIntegers[16] = "Sixteen"
namesOfIntegers[28] = "Twenty Eight"
print(namesOfIntegers)

if namesOfIntegers.isEmpty {
    print("Dictionary is empty")
}

    else{
    print(namesOfIntegers)
}

var airports: [String:String] = ["yyz":"Toronto Pearson", "DUB":"Dublin"]
airports["LHR"] = "London Heathrow"

airports["yyz"] = "TP International"

airports["XYZ"] = "SVP International"
print("airports : ",airports)

let oldValue = airports.updateValue("Dublin Airport", forKey: "DUB")

if let airportName = airports["AMD"] {
print("The Name of the airport is \(airportName).")
}
print(airports)
airports["Mars"] = nil

if let removeValue = airports.removeValue(forKey: "DUB"){
    print("The removed airport's name is \(removeValue).")
}
for (airportCode,airportName) in airports {
    print(airportCode,airportName)
}

for airportCode in airports.keys {
    print("Airport code: \(airportCode)")
}

for airportName in airports.values {
    print("Airport name: \(airportName)")
}
//<Key,Value> pairs
var d1 : Dictionary<String, String> = ["India":"Hindi","Canada":"English"]
print(d1)
print(d1.description)
print(d1["India"]!)
print(d1["Canada"]!)
print(["USA"])
d1["China"] = "Mandarin"

for (k,v) in d1{
    print("\(k) -> \(v)")
}
var d2 = ["India":"Hindi","Canada":"English"]
for (k,v) in d2{
    print("\(k) -> \(v)")
}

//Dictionary with any values type
var d3 = [String: AnyObject]()
d3["firstName"] = "SK" as AnyObject
d3["lastName"] = "Kaur" as AnyObject
d3["age"] = Int(50) as AnyObject
d3["salary"] = nil
print("d3",d3)

//Getting as a Key , value pair
for (k,v) in d3{
    print("\(k) -> \(v)")
}

//Declaring tuples
var x = (10,20,"Kaur")
print(x.0)
print(x.1)
print(x.2)

let http404Error = (404, "Not Found")
print(http404Error)

let (statusCode,statusMessage) = http404Error
print("statusCode:",statusCode)
print("statusMessage:",statusMessage)

let (codeOnly,_) = http404Error
print("codeOnly:",codeOnly)
let errorDescription = (Code: 404,Message:"Not Found")
print(errorDescription.Code,errorDescription.Message)

func add()
{
    print("I am a User Defined Function")
}
add()

func add(n1:Int, n2:Int){
    var sum : Int
    sum = n1 + n2
    print ("sum : ",sum)
}

add(n1:10, n2:20)
//Single Parameter
func welcome(name:String)
{
    print("Hello,\(name)")
    
}






welcome(name: "JK Patel")
func sub(a:Int, _ b:Int)
{
    let c = a - b
    print("Sub : \(c)")
}
sub(a: 30, 20)

//inout concept
func swipe(aa: inout Double, bb: inout Double)
{
    let temp = aa
    aa = bb
    bb = temp
}
var a = 8.0, b = 9.0
swipe(aa:&a , bb:&b)
print("a : \(a),b: \(b)")

func simpleInterest(amount:Double, noOfYears: Double, rate:Double = 5.0) ->
    Double{
        let si = amount * rate * noOfYears / 100
        return si
}
func display(n:Int...)
{
    for i in n{
        print(i)
    }
}
display(n:1,2,3,4,5)
display(n:10,20,30)

func display(numberValues:Int, parameters:[Int]...)
{
    
}


    

