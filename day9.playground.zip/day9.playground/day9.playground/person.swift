//
//  person.swift
//  day9.playground
//
//  Created by MacStudent on 2018-02-08.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import Foundation
class person {
    var firstName: String?
   var  lastName: String?
    var age: Int?

init(){
self.firstName = ""
self.lastName = ""
self.age = 0
}
    init(fname: String,lname: String, a: Int){
        self.firstName = fname
        self.lastName = lname
        self.age = a
}
}
