//
//  main.swift
//  day9.playground
//
//  Created by MacStudent on 2018-02-08.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import Foundation

let laptop = Product(name: "Laptop")

if let machine = laptop {
    print("Product name is \(machine.name)")
    

}

let anonymousMachine = Product(name: "")
if anonymousMachine == nil{
    print("The anonymous machine could not be initialised")
    
}

